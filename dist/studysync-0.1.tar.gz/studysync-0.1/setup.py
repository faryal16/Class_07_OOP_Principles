from setuptools import setup, find_packages

setup(
    name='studysync',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'termcolor',  # Add any other dependencies here
    ],
    entry_points={
        'console_scripts': [
            'studysync=main:main',  # Assumes you have a function named 'main' inside 'main.py'
        ],
    },
)
